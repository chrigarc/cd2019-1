Integrantes y número de cuenta de los miembros del equipo: 

Ángeles Martínez Ángela Janín | 314201009

Guevara Castro  Miguel Andres | 314091057

González Durán Érick 	      | 314271103

Rivas León Alexis             | 314215323

Colaboré en la práctica entendiendo el API de la biblioteca, al encontrar la forma de pintar aleatoriamente los colores de los nodos que sí tienen vecinos. 
